<html>
<body>
<form action="new.php">
<input type="submit" name="btnNext" value="Click for datatable">
</form>
</body>
</html>