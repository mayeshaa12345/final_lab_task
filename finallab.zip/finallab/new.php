<?php
$servername="localhost";
$username="root";
$password="";
$dbname="mylogin";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	$q="SELECT * from myinformation";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>ID</th><th>Name</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["ID"]}</td><td>{$row["Name"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>
