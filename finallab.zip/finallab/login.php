<html>
<head>
<link rel="stylesheet"href="login.css">
</head>
<body>
	<form action="mydata.php" onsubmit="return emptycheck()">
	    Username:<input type="text" name="uname" id="uname"><br>
		Password:<input type="password" name="pass" id="pass"><br>
		<input type="submit" name="btnLogin" value="Login">
	</form>
	<script>
	function emptycheck()
	{
		var username=document.getElementById('uname');
		var password=document.getElementById('pass');
		if(username.value=="" || password.value=="")
		{
			alert("Here username or password is empty");
			return false;
		}
		else
			return true;
	}
	</script>
</body>
</html>



